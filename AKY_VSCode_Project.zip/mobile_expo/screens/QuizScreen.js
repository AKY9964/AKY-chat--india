import React,{useEffect,useState} from 'react';
import { SafeAreaView, Text, View, TouchableOpacity, StyleSheet } from 'react-native';
import axios from 'axios';
export default function QuizScreen(){
  const [q,setQ]=useState(null);
  useEffect(()=>{ axios.get('http://10.0.2.2:4000/api/quiz/sample').then(r=>setQ(r.data)).catch(()=>setQ({q:'Which planet is red?',options:['Mars','Venus'],ans:0})); },[]);
  return (<SafeAreaView style={styles.c}><Text style={styles.title}>Quiz</Text>{q && (<View style={styles.card}><Text style={styles.question}>{q.q}</Text>{q.options.map((o,i)=>(<TouchableOpacity key={i} style={styles.opt}><Text style={{color:'#fff'}}>{o}</Text></TouchableOpacity>))}</View>)}</SafeAreaView>);
}
const styles = StyleSheet.create({ c:{flex:1,backgroundColor:'#000',padding:12}, title:{color:'#fff',fontSize:20,fontWeight:'700',marginBottom:12}, card:{backgroundColor:'#0b0b0b',padding:16,borderRadius:12}, question:{color:'#fff',fontSize:16,marginBottom:12}, opt:{backgroundColor:'#111',padding:12,borderRadius:8,marginBottom:8} });
