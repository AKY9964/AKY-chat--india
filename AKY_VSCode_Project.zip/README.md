AKY Chat - VS Code Ready Project (phase-1)
-----------------------------------------
This package is ready to open in VS Code.

Folders:
- web/             : static landing + quiz demo
- mobile_expo/     : Expo app scaffold (screens + assets)
- backend/         : Node Express backend (sample endpoints)
- admin/           : admin panel stub
- security/        : nginx conf, ufw script, firestore rules

Quick start (backend):
1. Open VS Code, then open terminal.
2. cd backend
3. npm install
4. node server.js
5. Test: http://localhost:4000/api/quiz/sample

Quick start (mobile):
1. cd mobile_expo
2. npm install
3. npx expo start
4. Open in Expo Go on your phone or emulator

Quick start (web):
- Serve web/ folder with any static host (Vercel/Netlify) or simple `npx http-server`.

Notes:
- Replace placeholder assets with your logo and splash images.
- Add authentication and persistent DB for production.
- See security/ for nginx and firewall templates.
