import React,{useEffect} from 'react';
import { View, Text, StyleSheet } from 'react-native';
export default function SplashScreen({navigation}){
  useEffect(()=>{ const t = setTimeout(()=>navigation.replace('Home'),1400); return ()=>clearTimeout(t); },[]);
  return (<View style={styles.c}><View style={styles.logo}><Text style={styles.logoText}>AK</Text></View><Text style={styles.p}>Powered by Jarvis</Text></View>);
}
const styles = StyleSheet.create({ c:{flex:1,backgroundColor:'#000',alignItems:'center',justifyContent:'center'}, logo:{width:140,height:140,borderRadius:28,backgroundColor:'#D40000',alignItems:'center',justifyContent:'center'}, logoText:{color:'#fff',fontSize:48,fontWeight:'700'}, p:{color:'#9b9b9b',marginTop:12}});
