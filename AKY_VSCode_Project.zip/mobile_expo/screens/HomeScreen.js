import React from 'react';
import { SafeAreaView, ScrollView, Text, TouchableOpacity, StyleSheet } from 'react-native';
export default function HomeScreen({navigation}){
  return (
    <SafeAreaView style={styles.c}>
      <ScrollView contentContainerStyle={{padding:20}}>
        <Text style={styles.title}>AKY Chat</Text>
        <TouchableOpacity style={styles.card} onPress={()=>navigation.navigate('Chat')}><Text style={styles.ct}>Open Chat</Text></TouchableOpacity>
        <TouchableOpacity style={styles.card} onPress={()=>navigation.navigate('Quiz')}><Text style={styles.ct}>Play Quiz</Text></TouchableOpacity>
        <TouchableOpacity style={styles.card} onPress={()=>navigation.navigate('Profile')}><Text style={styles.ct}>Profile</Text></TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({ c:{flex:1,backgroundColor:'#000'}, title:{color:'#fff',fontSize:24,fontWeight:'700'}, card:{backgroundColor:'#0b0b0b',padding:18,borderRadius:12,marginBottom:10}, ct:{color:'#D40000',fontWeight:'700'}});
