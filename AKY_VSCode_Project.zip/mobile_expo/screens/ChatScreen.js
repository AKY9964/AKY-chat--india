import React,{useState} from 'react';
import { SafeAreaView, FlatList, View, TextInput, TouchableOpacity, Text, StyleSheet } from 'react-native';
export default function ChatScreen(){
  const [text,setText]=useState(''); const [messages,setMessages]=useState([{id:'1',from:'them',text:'Hello!'}]);
  const send=()=>{ if(!text.trim()) return; setMessages(p=>[...p,{id:Date.now().toString(),from:'me',text}]); setText(''); };
  return (
    <SafeAreaView style={styles.c}>
      <FlatList data={messages} keyExtractor={i=>i.id} renderItem={({item})=>(<View style={[styles.msg,item.from==='me'?styles.me:styles.them]}><Text style={{color:'#fff'}}>{item.text}</Text></View>)} />
      <View style={styles.composer}><TextInput style={styles.input} value={text} onChangeText={setText} placeholder='Message' placeholderTextColor='#666' /><TouchableOpacity onPress={send} style={styles.send}><Text style={{color:'#fff'}}>Send</Text></TouchableOpacity></View>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({ c:{flex:1,backgroundColor:'#000',padding:12}, msg:{padding:10,borderRadius:10,marginVertical:6,maxWidth:'80%'}, me:{backgroundColor:'#D40000',alignSelf:'flex-end'}, them:{backgroundColor:'#111',alignSelf:'flex-start'}, composer:{flexDirection:'row',alignItems:'center'}, input:{flex:1,backgroundColor:'#111',padding:10,borderRadius:8,color:'#fff'}, send:{backgroundColor:'#D40000',padding:10,borderRadius:8} });
