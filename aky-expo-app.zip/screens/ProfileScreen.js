import React from 'react';
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity } from 'react-native';

export default function ProfileScreen(){
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.avatar}><Text style={{color:'#fff',fontSize:24}}>A</Text></View>
        <Text style={styles.name}>Anjali</Text>
      </View>
      <TouchableOpacity style={styles.btn}><Text style={{color:'#fff'}}>Edit Profile</Text></TouchableOpacity>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  container:{flex:1,backgroundColor:'#000',padding:20},
  header:{alignItems:'center',marginBottom:20},
  avatar:{width:96,height:96,borderRadius:18,backgroundColor:'#111',alignItems:'center',justifyContent:'center'},
  name:{color:'#fff',fontSize:18,fontWeight:'700',marginTop:10},
  btn:{backgroundColor:'#D40000',padding:12,borderRadius:10,alignItems:'center'}
});
