// Minimal offline-first quiz demo for web
(function(){
  const cats = {
    gk: [{id:'q1', q:'Which planet is known as the Red Planet?', options:['Venus','Mars','Jupiter','Saturn'], ans:1}]
  };
  document.getElementById('categories').innerHTML = '<button onclick="start()">Start Demo</button>';
  window.start = function(){ const q=cats.gk[0]; document.getElementById('questionBox').innerText=q.q; document.getElementById('options').innerHTML=q.options.map((o,i)=>`<div onclick="choose(${i})">${o}</div>`).join(''); window._q=q; };
  window.choose=function(i){ if(i===window._q.ans) alert('Correct'); else alert('Wrong'); };
})();
