const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const WebSocket = require('ws');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const PORT = process.env.PORT || 4000;
const server = require('http').createServer(app);
const wss = new WebSocket.Server({ server });

let sockets = new Map();

// Health check
app.get('/api/health', (req, res) => res.json({ok:true, time: Date.now()}));

// Sample quiz API (replace with real DB)
app.get('/api/quiz/sample', (req, res) => {
  res.json({ q: 'Which planet is known as the Red Planet?', options: ['Mars','Venus','Jupiter','Saturn'], ans: 0 });
});

// Save attempt (demo - in-memory)
let attempts = [];
app.post('/api/quiz/attempt', (req, res) => {
  const attempt = { id: uuidv4(), ...req.body, createdAt: Date.now() };
  attempts.push(attempt);
  return res.json({ok:true, attempt});
});

// Simple WS chat broadcast
wss.on('connection', (ws) => {
  const id = uuidv4();
  sockets.set(id, ws);
  console.log('ws connected', id);
  ws.on('message', (msg) => {
    for (let [k, s] of sockets) {
      if (s.readyState === WebSocket.OPEN) {
        s.send(JSON.stringify({ from: id, msg: msg.toString() }));
      }
    }
  });
  ws.on('close', () => { sockets.delete(id); console.log('ws closed', id); });
});

server.listen(PORT, ()=> console.log('AKY backend listening on', PORT));
