const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bodyParser = require('body-parser');
const app = express();
app.use(helmet());
app.use(cors());
app.use(bodyParser.json({limit:'50kb'}));
app.use(rateLimit({windowMs:60000,max:120}));
// sample endpoints
app.get('/api/health',(req,res)=>res.json({ok:true}));
app.get('/api/quiz/sample',(req,res)=>res.json({q:'Which planet is known as the Red Planet?',options:['Mars','Venus','Jupiter','Saturn'],ans:0}));
// admin stub (requires auth for production)
app.post('/api/admin/ban',(req,res)=>{ console.log('ban request',req.body); res.json({ok:true}); });
const PORT=process.env.PORT||4000; app.listen(PORT,()=>console.log('AKY backend listening on',PORT));
